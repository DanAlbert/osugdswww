#include "lesson03.h"

Lesson03::Lesson03()
{
}

bool Lesson03::init()
{
	if (!m_Window.createWindow(800, 600, 32, false, "Ne(w)He Lesson 3 - A rotating cube"))
	{
		return false;
	}

	glShadeModel(GL_SMOOTH);		// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);	// Black Background
	glClearDepth(1.0f);			// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);		// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);			// The Type Of Depth Testing To Do

	//Create a cube inside our vertex buffer

	m_Vertices.push_back(Vertex(-1.0f, -1.0f,  1.0f ));//Vertex
	m_Colors.push_back(Vertex(1.0, 0.0, 0.0));//Color
	m_Vertices.push_back(Vertex( 1.0f, -1.0f,  1.0f ));
	m_Colors.push_back(Vertex(1.0, 0.0, 0.0));
	m_Vertices.push_back(Vertex( 1.0f,  1.0f,  1.0f ));
	m_Colors.push_back(Vertex(1.0, 0.0, 0.0));
	m_Vertices.push_back(Vertex(-1.0f,  1.0f,  1.0f ));
	m_Colors.push_back(Vertex(1.0, 0.0, 0.0));

	m_Vertices.push_back(Vertex(-1.0f, -1.0f, -1.0f ));
	m_Colors.push_back(Vertex(1.0, 1.0, 0.0));
	m_Vertices.push_back(Vertex(-1.0f,  1.0f, -1.0f ));
	m_Colors.push_back(Vertex(1.0, 1.0, 0.0));
	m_Vertices.push_back(Vertex( 1.0f,  1.0f, -1.0f ));
	m_Colors.push_back(Vertex(1.0, 1.0, 0.0));
	m_Vertices.push_back(Vertex( 1.0f, -1.0f, -1.0f ));
	m_Colors.push_back(Vertex(1.0, 1.0, 0.0));

	m_Vertices.push_back(Vertex(-1.0f,  1.0f, -1.0f ));
	m_Colors.push_back(Vertex(1.0, 1.0, 1.0));
	m_Vertices.push_back(Vertex(-1.0f,  1.0f,  1.0f ));
	m_Colors.push_back(Vertex(1.0, 1.0, 1.0));
	m_Vertices.push_back(Vertex( 1.0f,  1.0f,  1.0f ));
	m_Colors.push_back(Vertex(1.0, 1.0, 1.0));
	m_Vertices.push_back(Vertex( 1.0f,  1.0f, -1.0f ));
	m_Colors.push_back(Vertex(1.0, 1.0, 1.0));

	m_Vertices.push_back(Vertex(-1.0f, -1.0f, -1.0f ));
	m_Colors.push_back(Vertex(0.0, 1.0, 1.0));
	m_Vertices.push_back(Vertex( 1.0f, -1.0f, -1.0f ));
	m_Colors.push_back(Vertex(0.0, 1.0, 1.0));
	m_Vertices.push_back(Vertex( 1.0f, -1.0f,  1.0f ));
	m_Colors.push_back(Vertex(0.0, 1.0, 1.0));
	m_Vertices.push_back(Vertex(-1.0f, -1.0f,  1.0f ));
	m_Colors.push_back(Vertex(0.0, 1.0, 1.0));

	m_Vertices.push_back(Vertex( 1.0f, -1.0f, -1.0f ));
	m_Colors.push_back(Vertex(0.0, 1.0, 0.0));
	m_Vertices.push_back(Vertex( 1.0f,  1.0f, -1.0f ));
	m_Colors.push_back(Vertex(0.0, 1.0, 0.0));
	m_Vertices.push_back(Vertex( 1.0f,  1.0f,  1.0f ));
	m_Colors.push_back(Vertex(0.0, 1.0, 0.0));
	m_Vertices.push_back(Vertex( 1.0f, -1.0f,  1.0f ));
	m_Colors.push_back(Vertex(0.0, 1.0, 0.0));

	m_Vertices.push_back(Vertex(-1.0f, -1.0f, -1.0f ));
	m_Colors.push_back(Vertex(0.0, 0.0, 1.0));
	m_Vertices.push_back(Vertex(-1.0f, -1.0f,  1.0f ));
	m_Colors.push_back(Vertex(0.0, 0.0, 1.0));
	m_Vertices.push_back(Vertex(-1.0f,  1.0f,  1.0f ));
	m_Colors.push_back(Vertex(0.0, 0.0, 1.0));
	m_Vertices.push_back(Vertex(-1.0f,  1.0f, -1.0f ));
	m_Colors.push_back(Vertex(0.0, 0.0, 1.0));

	//start with an Angle of 0
	m_RotationAngle = 0;

	return true;
}

//Here's where all the drawing happens
void Lesson03::draw()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear Screen And Depth Buffer
	glLoadIdentity();					// Reset The Current Modelview Matrix
	glTranslatef(0.0f, 0.0f, -8.0f);				// Move everything 8 units into the screen

	// We rotate the cube around the y axis at an angle of "rot",
	// the x-axis of 0.2*rot and z 0.4*rot so we might see each of its sides some time..
	//glRotatef(m_RotationAngle, 0.2, 1.0, 0.4);
	
	if (mouse[2] <= mouse[0]){
		glRotatef((mouse[0]-mouse[2]), 0, -.5, 0);
		}
	else{
		glRotatef((mouse[2]-mouse[0]), 0, .5, 0);
		}
	if (mouse[3] <= mouse[1]){
		glRotatef((mouse[1]-mouse[3]), -.5, 0, 0);
		}
	else{
		glRotatef((mouse[3]-mouse[1]), .5, 0, 0);
		}

	if(m_RotationAngle > 360.0) //prevent from having an angle greater than a float value can store ^^
	{
		m_RotationAngle -= 360.0;
	}

	//Now we need to tell OpenGL to use the arrays we filled with data
	glEnableClientState(GL_VERTEX_ARRAY);   //We want a vertex array
	glEnableClientState(GL_COLOR_ARRAY);    //and a color array

	glVertexPointer(3, GL_FLOAT, 0, &m_Vertices[0]);   //All values are grouped to three Floats, we start at the beginning of the array (offset=0) and want to use m_vertices as VertexArray
	glColorPointer(3, GL_FLOAT, 0, &m_Colors[0]);      //Same here, but use m_colors

	glDrawArrays(GL_QUADS, 0, m_Vertices.size()); // The cube consists only of quads, and we have nothing else in our array so we draw all vertices

	//Disable using the Vertex and Color array
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_VERTEX_ARRAY);
}
