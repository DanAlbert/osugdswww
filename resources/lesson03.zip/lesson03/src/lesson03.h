#ifndef _NEHE_LESSON_3
#define _NEHE_LESSON_3

#include "basecode/lesson.h"

#include <vector>

class Lesson03 : public NeHe::Lesson
{
	private:
		//We need a structure to store our vertices in, otherwise we just had a huge bunch of floats in the end
		struct Vertex
		{
			float x, y, z;

			Vertex(float x, float y, float z)
			{
				this->x = x;
				this->y = y;
				this->z = z;
			}
		};

		std::vector<Vertex> m_Vertices; //We have a vector of vertices, each vertex with its 3 coordinates
		std::vector<Vertex> m_Colors; //also 3 floats for colors, so we just use the Vertex-struct

		float m_RotationAngle; //used to store the angle at which we're rotating at the moment

		virtual void draw();
		
	public:
		Lesson03();
		virtual bool init();
};

#endif
